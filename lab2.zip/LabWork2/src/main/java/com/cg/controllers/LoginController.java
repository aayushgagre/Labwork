package com.cg.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.*;

@Controller
@RequestMapping("/")
public class LoginController {

	 @GetMapping
	    public String viewLogin(Model model) {
		 Login l=new Login();
	        System.out.println("Login controller");
	        model.addAttribute("login", l);
	        return "login";
	    }
	 
	 @PostMapping
	 public String login(Model model,
			  @ModelAttribute("login") Login login, BindingResult results)
	 {
		 String msg1="";
			System.out.println("Processing "+login.getUsername());
			if((!results.hasErrors()) && (login.getUsername()=="admin") &&(login.getPassword()=="admin")) {
				msg1="No Errors found!";
				model.addAttribute("msg",msg1);
				model.addAttribute("username",login.getUsername());
				return "operation";
			}
			else {
				msg1=results.getErrorCount()+ " errors occurred!";
				model.addAttribute("msg",msg1);
				model.addAttribute(results.getAllErrors());
				return "form";
			}
	 }
	
	}
	

