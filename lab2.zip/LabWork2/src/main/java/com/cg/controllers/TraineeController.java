package com.cg.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.Trainee;
import com.cg.services.TraineeService;

@Controller
@RequestMapping("/trainee")
public class TraineeController {
	
	@Autowired private TraineeService service;
	
	//on GET request just show FORM
	
	@GetMapping("/add")
	public String newSave(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "new-add";
	}
	
	@PostMapping("/add")
	public String newSave(Model model, @ModelAttribute Trainee trainee, BindingResult result) {
		if(result.hasErrors()) {
			model.addAttribute("msg","Invalid Form Input");
		}
		try {
			service.create(trainee);
			model.addAttribute("msg", "Trainee "+trainee.getTraineeId()+" added successfully");
			model.addAttribute("trainee	",new Trainee());//Empty the form fields on success
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
            model.addAttribute("msg",ex.getMessage());
		}
		return "new-add";
	}
	
}
