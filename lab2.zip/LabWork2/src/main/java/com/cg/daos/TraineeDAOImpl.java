package com.cg.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;

@Repository
public class TraineeDAOImpl implements TraineeDAO {

	@PersistenceContext
	private EntityManager em;

	private List<Trainee> trainee = new ArrayList<>();

	@Override
	public Trainee findById(int traineeId) {
		return em.find(Trainee.class, traineeId);
	}

	@Override
	public List<Trainee> getAll() {
		Query q = em.createQuery("from Trainee t"); // That's \"JPQL\" not SQL !!!
		return q.getResultList();

	}

	@Override
	public void update(int id, Trainee t) {

	}

	@Override
	public void save(Trainee t) {
		em.persist(t);
		em.flush();

	}

	@Override
	public void delete(Trainee t) {

	}

}
